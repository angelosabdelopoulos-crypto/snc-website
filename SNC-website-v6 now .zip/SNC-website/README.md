# SNC — Cinematic Commerce Prototype

A React + TypeScript prototype for SNC, combining a cinematic brand presentation with an e-commerce-oriented collection experience. This is still a development preview, not a live store.

## Stack
- React + TypeScript + Vite
- GSAP + ScrollTrigger for scroll-linked reveals
- Three.js for a lightweight metallic 3D object
- Lucide React icons

## Run locally
Requirements: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (normally http://localhost:5173).

## Production build

```bash
npm run build
npm run preview
```

## Structure
- `src/App.tsx` — page composition, navigation, animation setup and preview-bag state
- `src/components/BrandLogo.tsx` — reusable official SNC logo component
- `src/components/CartDrawer.tsx` — accessible preview cart dialog and quantity controls
- `src/components/Orb.tsx` — Three.js object lifecycle and reduced-motion handling
- `src/data/products.ts` — typed product catalogue, intentionally marked as concepts
- `src/styles.css` — responsive visual system and layouts
- `public/brand/snc-logo.png` — transparent PNG derived from the logo screenshot supplied by the owner
- `public/favicon.png` — browser icon using the same supplied mark
- `public/og-image.png` — social-sharing image using the same supplied mark
- `index.html` — document and social metadata

## This iteration
- Integrated the supplied fluffy SNC wordmark and its two stars in the header and footer.
- Cropped the supplied phone screenshot to the logo and removed its black background, preserving the pale-blue/white texture and fuzzy edges as a transparent PNG.
- Added a reusable `BrandLogo` component so the logo can be replaced centrally if an SVG/master file is supplied later.
- Added a favicon and social-sharing image derived from the same approved mark; no new logo concept or campaign photography was invented.
- Added a keyboard-accessible skip link and Escape-to-close behavior for the mobile navigation.
- Moved the site header and footer outside the main-content landmark.
- Removed the fake `hello@snc.example` mail link; the footer now clearly marks contact details as pending.
- Retained the typed product data module, accessible preview bag, reduced-motion handling and responsive layout from the previous iteration.

## Still not production-ready
- The logo is a transparent raster extraction from a screenshot, not the original vector artwork. A clean SVG or transparent master PNG would improve sharpness at all sizes.
- Product cards remain fictional visual placeholders, not confirmed SNC products. They must be replaced with owner-approved product names, descriptions and photography before launch.
- No prices, SKUs, sizes, color variants, stock or inventory service are configured.
- The bag is local UI state only. There is no checkout, payment provider, tax/shipping calculation, customer account, order confirmation or returns workflow.
- No approved hero/campaign photography or video has been supplied.
- Shipping destinations, rates, delivery estimates, returns/refunds policy, business/legal details, real contact email and social URLs are still needed.
- No analytics, cookie-consent configuration, complete SEO pass, formal screen-reader audit, cross-browser QA or deployment has been completed. The social-image metadata uses a site-relative path until the production domain is known; it should be changed to an absolute URL at launch.

## Information required next
1. A clean SNC logo master (SVG preferred; transparent high-resolution PNG acceptable).
2. The real first-drop product designs and approved product names.
3. For each product: front/back/detail images, description, material/care details, sizes, colors, SKU, price and stock status.
4. Approved campaign imagery/video, if any.
5. Real contact email and social profile URLs.
6. Shipping destinations, shipping rates, delivery estimates, returns/refunds policy and the business/legal details required for the store.
7. Preferred commerce platform. Shopify is a practical hosted option; a custom backend is also possible.
8. Payment provider/merchant account details. These must be configured securely through the provider/backend, never placed in frontend source code.

The existing local bag is a preview only and must not be presented as an order or payment flow.

## Product detail page iteration
- Added `src/components/ProductPage.tsx`, a complete responsive product-detail view with a three-view placeholder gallery, selectable colour swatches, size options, quantity control, product description, and expandable product/delivery information.
- Product cards now open the detail page instead of directly adding a generic item to the bag.
- Product sizes and colour swatches live in the typed `src/data/products.ts` catalogue and are explicitly placeholder values pending approval.
- Preview-bag lines now distinguish product + size + colour, so different variants remain separate and can be quantity-adjusted independently.
- The add-to-bag action requires a size selection and clearly states that it creates a local preview only; it does not create an order or payment.
- Gallery art is CSS-generated placeholder artwork. Replace it with approved product photography; no real product imagery has been fabricated.

### Product page content still required
For each actual product, provide approved product title, description, material/composition, care details, fit/measurements, size range, colour names, SKU, stock status, price, and image set (front, back, close-up/detail). Confirm shipping/returns text before showing it as policy.


## SNC first product presentation (user-approved reference)

The collection now presents the two products shown in the user's supplied reference image: **SNC Hoodie — 50€** and **SNC Cap — 30€**. The two product images are direct crops of the supplied reference board, isolating the hoodie and cap panels; no logo, embroidery, garment artwork, colour, typography or placement has been redesigned. The unrelated Instagram-profile panel is not included in product imagery.

Product data lives in `src/data/products.ts`. Product images are in `public/products/`. The hoodie colour swatches are sampled from the four colour chips visible in the reference; names and actual variant availability remain provisional. Hoodie sizes are placeholders pending confirmation. The preview bag calculates a local subtotal but does not process orders or payments.


## Confirmed launch options (6 Nov 2026)

- SNC Hoodie: €50, sizes S / M / L. Brown is the only currently available colour. The other three swatches from the supplied reference palette are visible but disabled and labelled as coming soon.
- SNC Cap: €30, brown only, one size.
- Checkout and payment processing are not connected. Google Pay is explicitly shown as not enabled; no payment method or credential is represented as active.
