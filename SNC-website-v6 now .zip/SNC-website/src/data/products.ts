/**
 * SNC launch product data.
 * Product imagery is taken directly from the user's supplied reference board.
 * Confirmed launch options: hoodie S/M/L in brown; cap in brown only.
 */
export type ProductStatus = "preview";
export type Product = {
  id: string;
  name: string;
  category: string;
  price: number;
  priceLabel: string;
  image: string;
  tone: "hoodie" | "cap";
  tag: string;
  status: ProductStatus;
  description: string;
  sizes: string[];
  colors: { name: string; swatch: string; available: boolean }[];
};

export const products: Product[] = [
  {
    id: "snc-hoodie",
    name: "SNC Hoodie",
    category: "Oversized fit · 450 GSM shown in reference",
    price: 50,
    priceLabel: "50€",
    image: "/products/snc-hoodie-reference.jpg",
    tone: "hoodie",
    tag: "01 / HOODIE",
    status: "preview",
    description: "The SNC hoodie, shown exactly as supplied in the original front-and-back product reference. The garment artwork and lettering have not been redesigned.",
    sizes: ["S", "M", "L"],
    colors: [
      { name: "Brown", swatch: "#493024", available: true },
      { name: "Warm brown", swatch: "#71503d", available: false },
      { name: "Dusty pink", swatch: "#c77e99", available: false },
      { name: "Sand", swatch: "#d4c0a8", available: false },
    ],
  },
  {
    id: "snc-cap",
    name: "SNC Cap",
    category: "Premium cotton · Structured fit · 3D embroidery",
    price: 30,
    priceLabel: "30€",
    image: "/products/snc-cap-reference.jpg",
    tone: "cap",
    tag: "02 / CAP",
    status: "preview",
    description: "The SNC cap, shown exactly as supplied in the original product reference, with the brown base and pink SNC embroidery.",
    sizes: ["ONE SIZE"],
    colors: [{ name: "Brown", swatch: "#493024", available: true }],
  },
];
