type BrandLogoProps = {
  loading?: "eager" | "lazy";
};

/** The official SNC mark supplied by the brand owner. */
export default function BrandLogo({ loading = "eager" }: BrandLogoProps) {
  return (
    <img
      className="brand-logo-image"
      src="/brand/snc-logo.png"
      alt=""
      aria-hidden="true"
      width={940}
      height={342}
      loading={loading}
      decoding="async"
      draggable={false}
    />
  );
}
