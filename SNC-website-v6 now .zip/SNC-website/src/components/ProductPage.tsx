import { useState } from "react";
import { ArrowLeft, ArrowUpRight, Check, ChevronDown, Plus, Minus } from "lucide-react";
import type { Product } from "../data/products";

type ProductSelection = { size: string; color: string };
type Props = { product: Product; onBack: () => void; onAdd: (product: Product, selection: ProductSelection) => void };

export default function ProductPage({ product, onBack, onAdd }: Props) {
  const [size, setSize] = useState(product.sizes.length === 1 ? product.sizes[0] : "");
  const [color, setColor] = useState(product.colors[0]?.name ?? "");
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState("");

  const addSelected = () => {
    if (!size) { setError("Select a size to continue."); return; }
    setError("");
    for (let i = 0; i < quantity; i += 1) onAdd(product, { size, color });
  };

  return (
    <section className="product-page section-pad" aria-labelledby="product-title">
      <div className="product-page-top">
        <button className="back-link" onClick={onBack}><ArrowLeft size={15} /> BACK TO COLLECTION</button>
        <span>{product.tag}</span>
      </div>
      <div className="product-detail-grid">
        <div className="product-gallery">
          <div className="product-gallery-main product-gallery-photo">
            <img src={product.image} alt={`${product.name}, original SNC design supplied by the brand`} />
          </div>
          <p className="gallery-note">ORIGINAL SNC PRODUCT REFERENCE — DESIGN UNCHANGED</p>
        </div>

        <div className="product-information">
          <div className="product-info-kicker"><span>{product.tag}</span><span> SNC COLLECTION</span></div>
          <h1 id="product-title">{product.name}</h1>
          <p className="product-subtitle">{product.category}</p>
          <div className="product-price-detail"><strong>{product.priceLabel}</strong><span>EUR</span></div>
          <p className="product-description">{product.description}</p>

          <div className="product-option-block">
            <div className="option-heading"><span>COLOUR</span><span>{color}</span></div>
            <div className="color-options">
              {product.colors.map((option) => (
                <button
                  key={option.name}
                  type="button"
                  className={`color-option ${color === option.name ? "selected" : ""} ${!option.available ? "unavailable" : ""}`}
                  onClick={() => { if (option.available) setColor(option.name); }}
                  aria-label={`${option.name}${option.available ? " — available" : " — coming soon"}`}
                  aria-pressed={color === option.name}
                  aria-disabled={!option.available}
                  disabled={!option.available}
                  title={option.available ? option.name : `${option.name} — coming soon`}
                >
                  <span style={{ background: option.swatch }} />
                </button>
              ))}
            </div>
            {product.tone === "hoodie" && <p className="option-disclaimer">BROWN IS CURRENTLY AVAILABLE. THE OTHER COLOURS FROM THE ORIGINAL PALETTE ARE SHOWN AS COMING SOON.</p>}
          </div>

          <div className="product-option-block size-block">
            <div className="option-heading"><span>SIZE</span><span>{product.tone === "cap" ? "ONE SIZE" : "SIZE"}</span></div>
            <div className="size-options">
              {product.sizes.map((option) => (
                <button key={option} className={size === option ? "size-option selected" : "size-option"} onClick={() => { setSize(option); setError(""); }} aria-pressed={size === option}>{option}</button>
              ))}
            </div>
            {product.tone === "hoodie" && <p className="option-disclaimer">AVAILABLE SIZES: S / M / L.</p>}
            {error && <p className="selection-error" role="alert">{error}</p>}
          </div>

          <div className="product-buy-row">
            <div className="detail-quantity" aria-label="Quantity selector">
              <button onClick={() => setQuantity((value) => Math.max(1, value - 1))} aria-label="Decrease quantity" disabled={quantity === 1}><Minus size={13} /></button>
              <span aria-live="polite">{quantity}</span>
              <button onClick={() => setQuantity((value) => Math.min(10, value + 1))} aria-label="Increase quantity" disabled={quantity === 10}><Plus size={13} /></button>
            </div>
            <button className="add-to-bag-button" onClick={addSelected}>ADD TO PREVIEW BAG · {product.priceLabel} <ArrowUpRight size={16} /></button>
          </div>
          <p className="preview-disclaimer"><Check size={13} /> PREVIEW BAG ONLY — CHECKOUT IS NOT CONNECTED.</p>

          <details className="product-accordion">
            <summary>PRODUCT DETAILS <ChevronDown size={15} /></summary>
            <p>{product.description} Final fabric composition, care instructions and measurements have not yet been supplied.</p>
          </details>
          <details className="product-accordion">
            <summary>DELIVERY & RETURNS <ChevronDown size={15} /></summary>
            <p>Shipping costs, dispatch times and return terms will be added once the brand policies are confirmed.</p>
          </details>
        </div>
      </div>
    </section>
  );
}
