import { useEffect, useRef } from "react";
import * as THREE from "three";

export default function Orb() {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = host.current;
    if (!el || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let renderer: THREE.WebGLRenderer | undefined;
    let animationFrame = 0;
    let observer: ResizeObserver | undefined;
    let geometry: THREE.BufferGeometry | undefined;
    let material: THREE.Material | undefined;

    try {
      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
      camera.position.z = 4.5;

      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
      renderer.setSize(el.clientWidth, el.clientHeight);
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      el.appendChild(renderer.domElement);

      geometry = new THREE.IcosahedronGeometry(1.15, 5);
      material = new THREE.MeshStandardMaterial({
        color: 0x9b9b9b,
        metalness: 0.92,
        roughness: 0.19,
      });
      const sphere = new THREE.Mesh(geometry, material);
      scene.add(sphere);
      scene.add(new THREE.AmbientLight(0xffffff, 0.8));

      const key = new THREE.PointLight(0xffffff, 26);
      key.position.set(3, 3, 4);
      scene.add(key);

      const rim = new THREE.PointLight(0x6f86a4, 14);
      rim.position.set(-3, -1, -2);
      scene.add(rim);

      const resize = () => {
        camera.aspect = el.clientWidth / Math.max(el.clientHeight, 1);
        camera.updateProjectionMatrix();
        renderer?.setSize(el.clientWidth, el.clientHeight);
      };

      observer = new ResizeObserver(resize);
      observer.observe(el);

      const animate = () => {
        animationFrame = window.requestAnimationFrame(animate);
        sphere.rotation.y += 0.0025;
        sphere.rotation.x = Math.sin(performance.now() * 0.00025) * 0.12;
        renderer?.render(scene, camera);
      };
      animate();
    } catch {
      el.classList.add("webgl-fallback");
    }

    return () => {
      window.cancelAnimationFrame(animationFrame);
      observer?.disconnect();
      geometry?.dispose();
      material?.dispose();
      renderer?.dispose();
      if (renderer?.domElement.parentElement === el) {
        el.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      className="orb"
      ref={host}
      role="img"
      aria-label="Abstract metallic 3D object"
    />
  );
}
