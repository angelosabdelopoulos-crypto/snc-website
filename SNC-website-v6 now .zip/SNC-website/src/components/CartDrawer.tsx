import { useEffect, useRef } from "react";
import { ArrowUpRight, Minus, Plus, X } from "lucide-react";
import type { Product } from "../data/products";

export type CartLine = {
  key: string;
  product: Product;
  quantity: number;
  size: string;
  color: string;
};

type CartDrawerProps = {
  open: boolean;
  items: CartLine[];
  onClose: () => void;
  onIncrease: (lineKey: string) => void;
  onDecrease: (lineKey: string) => void;
};

export default function CartDrawer({ open, items, onClose, onIncrease, onDecrease }: CartDrawerProps) {
  const closeButton = useRef<HTMLButtonElement>(null);
  const previousFocus = useRef<HTMLElement | null>(null);
  const total = items.reduce((sum, line) => sum + line.quantity, 0);
  const subtotal = items.reduce((sum, line) => sum + line.product.price * line.quantity, 0);

  useEffect(() => {
    if (!open) return;
    previousFocus.current = document.activeElement as HTMLElement | null;
    closeButton.current?.focus();
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const dialog = document.getElementById("snc-cart-dialog");
        const focusable = dialog?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])');
        if (!focusable?.length) return;
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = previousOverflow;
      previousFocus.current?.focus();
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="drawer-backdrop" onMouseDown={onClose}>
      <aside className="cart-drawer" id="snc-cart-dialog" role="dialog" aria-modal="true" aria-labelledby="snc-cart-title" onMouseDown={(event) => event.stopPropagation()}>
        <div className="drawer-head"><div><span className="eyebrow">SNC / YOUR SELECTION</span><h2 id="snc-cart-title">PREVIEW BAG ({total})</h2></div><button ref={closeButton} onClick={onClose} aria-label="Close bag"><X /></button></div>
        {items.length === 0 ? <p className="empty-bag">Your bag is currently empty.</p> : (
          <div className="bag-items" aria-live="polite">
            {items.map(({ key, product, quantity, size, color }) => (
              <div className="bag-item" key={key}>
                <div><b>{product.name}</b><span>{product.tag}</span><span>SIZE: {size} · {color}</span><span>{product.priceLabel} × {quantity}</span>
                  <div className="quantity-control" aria-label={`Quantity for ${product.name}`}>
                    <button onClick={() => onDecrease(key)} aria-label={`Decrease ${product.name} quantity`}><Minus size={14} /></button><span aria-live="polite">{quantity}</span><button onClick={() => onIncrease(key)} aria-label={`Increase ${product.name} quantity`}><Plus size={14} /></button>
                  </div>
                </div>
                <button onClick={() => onDecrease(key)} aria-label={`Remove one ${product.name}`}><X size={16} /></button>
              </div>
            ))}
          </div>
        )}
        <div className="drawer-foot"><div className="bag-subtotal"><span>SUBTOTAL</span><strong>{subtotal.toFixed(2)}€</strong></div><p>Checkout is not active yet. Payment methods are still being configured; Google Pay is not available at this stage.</p><div className="payment-pending" aria-label="Payment methods not configured"><span>PAYMENT METHODS</span><strong>COMING SOON</strong><small>Google Pay · Not enabled</small></div><button className="checkout-button" onClick={onClose}>CONTINUE EXPLORING <ArrowUpRight size={16} /></button></div>
      </aside>
    </div>
  );
}
